package ittapiros;

import java.util.Random;
import java.util.Scanner;

public class IttAPiros {

    public static void main(String[] args) {
        /* golyó elhelyezése a pohár alatt */
        Random rnd = new Random();
        int also = 1, felso = 3;
        //int golyoHelye = 2;
        int golyoHelye = rnd.nextInt(felso) + also;
        
        /* kezdés kirajzolása */
        System.out.println("Hol a golyó?");
        System.out.println("_ _ _");
        System.out.println("1 2 3");
        
        /* tipp "bekérése" */
        Scanner sc = new Scanner(System.in);
        System.out.print("tipp:");
        int tipp = sc.nextInt();
        //System.out.printf("tipp: %d\n", tipp);
        
        /* tipp ellenőrzése: 1,2,3 lehet csak!*/
        //if(!(tipp == 1 || tipp == 2 || tipp == 3)){
        if(tipp != 1 && tipp != 2 && tipp != 3){
            //ha hibás adatot kaptunk
            tipp = rnd.nextInt(felso) + also;
        }
        
        /* további ellenőrzés lehetne szövegeen bekérni
        és azt ellenőrizni, hogy tipp != "1" || stb
        szöveges bekérés esetén nem száll ell  a prg.
        akkor sem, ha a user betűt ad meg szám helyett
  
        */
        
        /* eredmény */
        String valasz = "NEM talált!";
        if(tipp == golyoHelye){
            //System.out.printf("Talált! (%d->%d)\n",golyoHelye, tipp);
            valasz = "Talált!";
        }/*else{
            System.out.printf("NEM talált! (%d->%d)\n",golyoHelye, tipp);
        }*/

        System.out.printf("%s (%d->%d)\n",valasz, golyoHelye, tipp);
    }
    
}
