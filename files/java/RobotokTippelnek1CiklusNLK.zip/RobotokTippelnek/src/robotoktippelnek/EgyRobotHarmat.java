package robotoktippelnek;
/* Gondolunk 1 számra 1..10 között
 * Egy robot próbálkozhat háromszor,hogy eltalálja!
 * Írjuk ki, ha egyik tipp sem talált, vagy azt, hogy melyik tippje volt jó!
*/
import java.util.Random;

public class EgyRobotHarmat {
    public static void main(String[] args) {
        Random rnd = new Random();
        
        int also = 1, felso = 10;
        int gondoltSzam = rnd.nextInt(felso) + also;
        int robot1Tipp = rnd.nextInt(felso) + also;
        int robot2Tipp = rnd.nextInt(felso) + also;
        int robot3Tipp = rnd.nextInt(felso) + also;
        
        /* TESZTELÉSHEZ */
        System.out.println("*** DEBUG ***");
        gondoltSzam = 7;
        robot1Tipp = 7;
        robot2Tipp = 7;
        robot3Tipp = 7;
        System.out.println("a 3 tipp:");
        System.out.println("1.: " + robot1Tipp);
        System.out.println("2.: " + robot2Tipp);
        System.out.println("3.: " + robot3Tipp);
        System.out.println("*** DEBUG vége ***");
        /* TESZTELÉS vége */
        
        /* Ha valamelyik tipp jó, akkor a többit nem nézzük meg!
         * CSAK EGY eredményt írunk ki, 
         * az előző vizsgálattól függ, hogy a következőt nézzük e!
         * if/else szerkezet kell!
        */
        //boolean vanTalalat = false;
        int talalatSzama = 0;
        if(gondoltSzam == robot1Tipp){
            //vanTalalat = true;
            talalatSzama = 1;
        }else if(gondoltSzam == robot2Tipp){
            //vanTalalat = true;
            talalatSzama = 2;
        }
        else if(gondoltSzam == robot3Tipp){
            //vanTalalat = true;
            talalatSzama = 3;
        }
        
        /* minden szövegmódosítás és kiíró logika 1 helyen van! */
        System.out.println("A gondolt szám: " + gondoltSzam);
        //if(vanTalalat){
        if(talalatSzama > 0){
            System.out.printf("A robot %d. tippje helyes volt!\n", talalatSzama);
        }else{
            System.out.println("Nem sikerült 3 tippből eltalálni!");
        }
    }
}
