package robotoktippelnek;
/* Gondolunk 1 számra 1..10 között
 * Három robot próbálkozhat, egyet-egyet tippelhetnek!
 * Írjuk ki, ha egyik robot sem találta el, vagy azt, hogy melyik robot(ok) találták el!
*/
import java.util.Random;

public class HaromRobotEgyetEgyet {
    public static void main(String[] args) {
        Random rnd = new Random();
        int also = 1, felso = 10;
        int gondoltSzam = rnd.nextInt(felso) + also;
        int robot1Tippje = rnd.nextInt(felso) + also;
        int robot2Tippje = rnd.nextInt(felso) + also;
        int robot3Tippje = rnd.nextInt(felso) + also;
        
        /* TESZTELÉSHEZ */
        gondoltSzam = 7;
        robot1Tippje = 7;
        robot2Tippje = 7;
        robot3Tippje = 7;
        /* TESZTELÉS vége */
        
        System.out.println("A gondolt szám: " + gondoltSzam);
//        System.out.println("1. robot tippje: " + robot1Tippje);
//        System.out.println("2. robot tippje: " + robot2Tippje);
//        System.out.println("3. robot tippje: " + robot3Tippje);
        String szoveg = "robot tippje:";
//        System.out.printf("1. %s %d\n", szoveg, robot1Tippje);
//        System.out.printf("2. %s %d\n", szoveg, robot2Tippje);
//        System.out.printf("3. %s %d\n", szoveg, robot3Tippje);
        int robotSzama = 0;
        robotSzama = robotSzama + 1;
        System.out.printf("%d. %s %d\n",robotSzama, szoveg, robot1Tippje);
        robotSzama = robotSzama + 1;
        System.out.printf("%d. %s %d\n",robotSzama, szoveg, robot2Tippje);
        robotSzama = robotSzama + 1;
        System.out.printf("%d. %s %d\n",robotSzama, szoveg, robot3Tippje);
        boolean voltTalalat = false;
        szoveg = "";
        /* az előző ellenőrzés nem befolyásolja a következőt!
         * az eredménytől függetlenülmegnézzük mindegyik robot tippjét!
         * különálló if szerkezet kell!
        */
        if(gondoltSzam == robot1Tippje){
            //System.out.println("Az 1. robot eltatlálta!");
            //szoveg = "Az 1. robot eltatlálta!\n";
            szoveg = "Az 1. ";
            voltTalalat = true;
        }
        if(gondoltSzam == robot2Tippje){
            //System.out.println("A 2. robot eltatlálta!");
            //szoveg = szoveg + "A 2. robot eltatlálta!\n";
            szoveg = szoveg + "A 2. ";
            voltTalalat = true;
        }
        if(gondoltSzam == robot3Tippje){
            //System.out.println("A 3. robot eltatlálta!");
            //szoveg = szoveg + "A 3. robot eltatlálta!\n";
            szoveg = szoveg + "A 3. ";
            voltTalalat = true;
        }
        
        /* 1 helyen a kiíró logika,ha pl fájlba akarom írni
        csak ezen az 1 helyen kell változtani */
        //if(voltTalalat == false){
        if(!voltTalalat){
            //System.out.println("Egyik robot sem találta el");
            szoveg = "Egyik robot sem találta el";
        }else{
            /* egy helyen van a szöveg, ha pl a helyesírát kell javítani */
          System.out.println(szoveg + " robot eltalálta!"); //korábban: robot eltatlálta 
        }
        
        /* 1 helyen a kiíró logika,ha pl fájlba akarom írni
        csak ezen az 1 helyen kell változtani */
        //System.out.println(szoveg);
    }
    
}
