package nyugtaprojektek;

public class Nyugta1 {

    public static void main(String[] args) {
        System.out.println("******************");
        System.out.println("     Nyugta 1");
        System.out.println("******************");
        System.out.println("Tétel 1:    350 Ft");
        System.out.println("Tétel 2:     90 Ft");
        System.out.println("Tétel 3:    650 Ft");
        System.out.println("==================");
        System.out.println("Összesen:  1090 Ft");
        System.out.println("------------------");
        System.out.println("Kedvezmény: 109 Ft");
        System.out.println("(10%)");
        System.out.println("==================");
        System.out.println("Fizetendő:  981 Ft");
        System.out.println("------------------");
        System.out.println("");
        System.out.print("_______");
        System.out.print("   ");
        System.out.println("_______");
        System.out.print(" Dátum");
        System.out.print("   ");
        System.out.println("   Név");
        System.out.println("******************");
        System.out.println("        CÉG");
        System.out.println("******************");
    }
    
}
