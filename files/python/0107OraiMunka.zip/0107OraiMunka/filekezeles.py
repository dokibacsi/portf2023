print(
    """
    1.	Hozz létre egy file-t proba.txt néven, melynek a 
    tartalma legyen a neved (Pythonban írasd a fileba a 
    szöveget filekezeléssel)!
    a.	Egy másik sorba írd be az osztályodat!
    b.	Írasd ki a teljes file tartalmát, majd csak a második sort, majd az első 5 karaktert!
    """
)

eroforras=open('fileok\proba.txt',"w",encoding="utf-8")
eroforras.write("Rózsás Adrienn")
eroforras.write("\ntanár")
#második megoldás
#print("\ntanár2",file=eroforras)
eroforras.close()
print("Teljes fájl:")
eroforras=open("fileok\proba.txt","r",encoding="utf-8")
#első megoldás
"""
teljesSzoveg=eroforras.read()
print(teljesSzoveg)
"""
#második megoldás
teljesSzoveg=eroforras.readlines()
#print(teljesSzoveg)
ciklusValtozo=0
while ciklusValtozo<len(teljesSzoveg):
    print(teljesSzoveg[ciklusValtozo].strip())
    ciklusValtozo+=1
eroforras.close()

#majd csak a második sort
print("Második sor: ")
eroforras=open("fileok\proba.txt","r",encoding="utf-8")
elsoSor=eroforras.readline()
masodikSor=eroforras.readline()
print(masodikSor)

#az első 5 karaktert
print("Az első 5 karaktert: ")
eroforras=open("fileok\proba.txt","r",encoding="utf-8")
elsoOt=eroforras.read(5)
print(elsoOt)