class Diak:
    #osztályváltozók
    nev=""
    evfolyam=""
    atlag=0.0

    #osztály metódusok
    #konstruktor
    def __init__(self,nev,evfolyam,atlag):
        self.nev=nev
        self.evfolyam=evfolyam
        atlag=atlag.replace(",",".")
        atlag=float(atlag)
        self.atlag=atlag


    #objektum kiírásának befolyásolása, felülírás
    def __str__(self):
        return "Név: {}, évfolyam: {}, atlag: {}.".format(self.nev,self.evfolyam, self.atlag)


