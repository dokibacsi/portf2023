import random

print(
    """
    Hozz létre egy 20 elemű listát véletlen pozitív kétjegyű számokkal feltöltve, az utolsó eleme legyen páratlan!
Majd valósítsd meg a tanult tételeket metódusként, futtasd is le!
Eljárások:  	
	listaFeltolt() feltölti a listát elemekkel, az utolsó elem páratlan.
	kiir() A lista elemeit vesszővel elválasztva írd ki, az utolsó után ne legyen vessző.
	osszegzes() Mennyi a lista elemeinek összege?
	eldontes() Van-e 5-tel osztható lista elem?
	kivalasztas() Írd ki a lista első páratlan elemét, és sorszámát!
	linearisKereses() Van-e a tömbben 24?
	megszamolas() Írd ki hány páros elem van a listában!
	maximumKivalasztas() Melyik elem értéke a legnagyobb a listában, hol található?


    """
)
lista=[]
N=20

def listaFeltolt():
    #listaFeltolt() feltölti a listát elemekkel, az utolsó elem páratlan.
    #első 19 elem
    ciklusvaltozo=0
    while ciklusvaltozo<N-1:
        #kétjegyű pozitív véletlen szám
        szam=random.randint(10,99)
        #hozzá kell fűzni alistához
        lista.append(szam)
        ciklusvaltozo+=1
    #utolsó elem
    szam = random.randint(10, 99)
    while not szam%2==1:
        szam = random.randint(10, 99)
    lista.append(szam)

def kiir():
    #kiir() A lista elemeit vesszővel elválasztva írd ki, az utolsó után ne legyen vessző.
    ciklusValtozo=0
    while ciklusValtozo<len(lista):
        if ciklusValtozo==len(lista)-1:
            print(lista[ciklusValtozo])
        else:
            print(str(lista[ciklusValtozo])+",",end="")
        ciklusValtozo+=1

def osszegzes():
    #osszegzes() Mennyi a lista elemeinek összege?
    ciklusValtozo = 0
    osszeg=0
    while ciklusValtozo<len(lista):
        osszeg+=lista[ciklusValtozo]
        ciklusValtozo+=1
    print("A lista elemeinek összege: {}.".format(osszeg))

def megszamlalas():
    #Írd ki hány páros elem van a listában!
    ciklusValtozo = 0
    db = 0
    while ciklusValtozo < len(lista):
        if lista[ciklusValtozo]%2==0:
            db+=1
        ciklusValtozo += 1
    print("A listában szereplő páros elemek száma: {}.".format(db))

def maximumKivalasztas():
    #maximumKivalasztas() Melyik elem értéke a legnagyobb a listában, hol található?
    maxErtek=lista[0]
    maxHely=0
    ciklusValtozo=1
    while ciklusValtozo<len(lista):
        if lista[ciklusValtozo]>maxErtek:
            maxErtek=lista[ciklusValtozo]
            maxHely=ciklusValtozo
        ciklusValtozo+=1
    print("A lista legnagyobb eleme: {}, helye: {}".format(maxErtek,maxHely+1))

def minimumKivalasztas():
    # minimumKivalasztas() Melyik elem értéke a legkisebb a listában, hol található?
    minErtek = lista[0]
    minHely = 0
    ciklusValtozo = 1
    while ciklusValtozo < len(lista):
        if lista[ciklusValtozo] < minErtek:
            minErtek = lista[ciklusValtozo]
            minHely = ciklusValtozo
        ciklusValtozo += 1
    print("A lista legkisebb eleme: {}, helye: {}".format(minErtek, minHely + 1))
#főprogram
listaFeltolt()
kiir()
osszegzes()
megszamlalas()
maximumKivalasztas()
minimumKivalasztas()
