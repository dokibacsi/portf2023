import diak
print(
    """
    1.	Hozz létre egy minimum 3 soros szöveges file-t, melynek a tartalma legyen pl.:
Név/Évfolyam/Átlag
Gipsz Jakab/1/4,5
Pán Péter/2/3,6
a.	Készíts osztályt, mely képes az adatok eltárolására!
b.	Olvasd be a file tartalmát (írasd is ki)!
c.	Add meg, hány sora van!
d.	Számold ki a suli átlagot!
e.	Hány elsős van?
f.	Add meg a legnagyobb átlagot!

    """
)
#metódusok
adatok=[]

def beolvas():
    #Olvasd be a file tartalmát
    beFajl=open('fileok/osztaly.txt','r',encoding="utf-8")
    #elso sor
    beFajl.readline()
    #többi sor
    sorok=beFajl.readlines()
    #print(sorok)
    for sor in sorok:
        #/n eltávolítása
        adat=sor.strip()
        #el kell darabolnom a / jelek mentén
        adat=adat.split("/")
        #print(adat)
        #osztály példány létrehozása
        fsorom=diak.Diak(adat[0],adat[1],adat[2])
        #print(fsorom)
        #print(type(fsorom.atlag))
        #listába elhelyezés
        adatok.append(fsorom)

def kiir():
    #Olvasd be a file tartalmát (írasd is ki)!
    for elem in adatok:
        print(elem)

def sorokSzama():
    #Add meg, hány sora van!
    print("A sorok száma: ",len(adatok),".")

def atlag():
    #Számold ki a suli átlagot!
    #összegzés
    osszeg=0
    for diak in adatok:
        osszeg+=diak.atlag
    if len(adatok)==0:
        print("nincs diák az osztályban átlaga 0.")
    else:
        atlag=osszeg/len(adatok)
        print("Az osztály átlaga {}.".format(atlag))

def elsosokSzama():
    #Hány elsős van?
    db=0
    for elem in adatok:
        if elem.evfolyam=="1":
            db+=1
    print("Az elsősök száma: {}".format(db))

def legnagyobbAtlag():
    #Add meg a legnagyobb átlagot!
    #maximum kiválasztás
    maxErtek=adatok[0].atlag
    maxNev=adatok[0].nev

    ciklusValtozo=1
    while ciklusValtozo<len(adatok):
        if maxErtek<adatok[ciklusValtozo].atlag:
            maxErtek=adatok[ciklusValtozo].atlag
            maxNev=adatok[ciklusValtozo].nev
        ciklusValtozo+=1
    print("A legnagyobb átlag: {}, neve: {}".format(maxErtek,maxNev))

#főprogram
beolvas()
kiir()
sorokSzama()
atlag()
elsosokSzama()
legnagyobbAtlag()
