import diak
print(
    """
    1.	Hozz létre egy minimum 3 soros szöveges file-t, melynek a tartalma legyen pl.:
Név/Évfolyam/Átlag
Gipsz Jakab/1/4,5
Pán Péter/2/3,6
a.	Készíts osztályt, mely képes az adatok eltárolására!
b.	Olvasd be a file tartalmát (írasd is ki)!
c.	Add meg, hány sora van!
d.	Számold ki a suli átlagot!
e.	Hány elsős van?
f.	Add meg a legnagyobb átlagot!

    """
)

jakab=diak.Diak("Gipsz Jakab","1","3.4")
print(jakab.nev)
print(jakab.atlag)
print(jakab.evfolyam)
jakab.nev="Gipsz János"
print(jakab.nev)
print(jakab)

peter=diak.Diak("Pán Péter","2","3.6")
print(peter)
