eroforras=open("fajlok/teszt2.txt", "r")
fajl=eroforras.read()
print(fajl)