eroforras=open("teszt1.txt","r")
fajl=eroforras.read()
print(fajl)