import os
#mappa törlése
os.rmdir("torol")