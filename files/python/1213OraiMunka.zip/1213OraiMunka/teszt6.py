eroforras=open("fajlok/tesz6.txt","r",encoding="utf-8")
print(eroforras.read())