eroforras=open("fajlok/notepades.txt","r")
print(eroforras.read())