from Diak_f import *


def file_beolvasas():
    diak_lista = []
    # megnyitjuk olvasásra a file-t
    f = open("szfa1.txt", "r", encoding="utf8")
    # első sor beolvasása
    # print(f.readline())
    f.readline()
    # adatok beolvasása
    sorok = f.readlines()
    f.close()
    # print(sorok)
    for i in range(len(sorok)):
        # gerenda/lista darabolása
        darabok = sorok[i].strip().split("*")
        diak = Diak(darabok[0], darabok[1], darabok[2], darabok[3])
        # print(diak)
        diak_lista.append(diak)
    return diak_lista


def lista_merete(lista):
    # \t jelentése: tabulátor
    print(f"1. feladat\n\tA diákok száma: {len(lista)}.")


# sorozatszámítás tétel
def atlaga(lista):
    osszeg = 0
    meret = len(lista)
    for i in range(meret):
        osszeg += lista[i].atlag
    print(f"2. feladat\n\tA diákok átlaga: {osszeg/meret:.1f}.")


# Az első legnagyobb átlagú diák neve
# maximumkiválasztás tétel
def okos(lista):
    max_index = 0
    for i in range(1, len(lista)):
        if lista[i].atlag > lista[max_index].atlag:
            # indexeket tárolunk!!!
            max_index = i
    print(f"3. feladat\n\tAz első legnagyobb átlagú diák neve: {lista[max_index].nev}.")


# Megszámlálás tétel
# Hány darab elsős van a diákok között?
# továbbfejlesztés: Hány százaléka a diákoknak elsős?
def megszalalas(lista):
    db = 0
    for i in range(len(lista)):
        if lista[i].evfolyam == 1:
            db += 1
    print(f"4.Feladat:\n\tElsős diákok száma(%-ban): {db/len(lista)*100:.2f}")
