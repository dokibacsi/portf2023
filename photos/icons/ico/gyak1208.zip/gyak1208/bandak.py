class Bandak:
    def __init__(self, sor):
        # darabolás
        darabok = sor.strip().split("-")
        self.nev = darabok[0]
        self.letszam = int(darabok[1])

    def __str__(self):
        return f"Név: {self.nev}, Létszám: {self.letszam}"