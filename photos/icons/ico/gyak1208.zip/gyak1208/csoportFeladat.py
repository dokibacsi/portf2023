from bandak import *

def fileBeolvasas(jel):
    bandaLista = []
    file = open("egyuttes.txt", "r", encoding="utf8")
    # elsosor
    # file.readline()
    # tobbisor
    sorok = file.readlines()
    file.close()
    for i in range(len(sorok)):
        # példányosítás
        bandak = Bandak(sorok[i])
        bandaLista.append(bandak)
        print(bandak)
    return bandaLista
def feladat4(bandalista):
    for i in range(len(bandalista)):
        print(bandalista[i].letszam)