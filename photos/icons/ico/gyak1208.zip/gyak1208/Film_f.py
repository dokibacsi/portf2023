# Cím;Rendező;Főszereplő;Év;Perc
class Film:
    def __init__(self, sor: str):
        adatok = sor.strip().split(";")
        self.cim = adatok[0]
        self.rendezo = adatok[1]
        self.foszereplo = adatok[2]
        self.ev = int(adatok[3])
        self.perc = int(adatok[4])
        