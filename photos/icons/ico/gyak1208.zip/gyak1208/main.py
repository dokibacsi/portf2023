import feladatok
# import csoportFeladat
import file_be_film

#diakok = feladatok.file_beolvasas()
#feladatok.lista_merete(diakok)
#feladatok.atlaga(diakok)
#feladatok.okos(diakok)
#feladatok.megszalalas(diakok)

#csoportfeladat:
# bandak = csoportFeladat.fileBeolvasas("-")
# csoportFeladat.feladat4(bandak)
file_be_film.file_beolvasas()