from Film_f import *

def file_beolvasas():
    # filmek
    filmek = []
    # megnyitom olvasásra
    f = open("film.txt", "r", encoding="utf8")
    # első sor ?
    f.readline()
    # sorokra bontás
    sorok = f.readlines()
    f.close()
    # sorokon végigmegyek
    for i in range(len(sorok)):
        # peldanyositas
        film = Film(sorok[i])
        # print(film.foszereplo)
        filmek.append(film)
    print(len(filmek))
