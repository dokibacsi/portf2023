class Diak:
    def __init__(self, nev, evfolyam, atlag, ev):
        self.nev = nev
        self.evfolyam = int(evfolyam)
        self.atlag = float(atlag.replace(",", "."))
        self.ev = int(ev[:4])

    def __str__(self):
        return f"Név: {self.nev}\nÉvfolyam: {self.evfolyam}\nÁtlag: {self.atlag}\nÉv: {self.ev}"
